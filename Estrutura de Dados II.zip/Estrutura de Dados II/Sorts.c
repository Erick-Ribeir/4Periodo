#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#define TAM 10

int main(){
	setlocale(LC_ALL, "");
	
	int numeros[TAM];
	int indice,auxiliar, contador;
	int troca; //flag
	
	printf("D�gite 10 n�meros aleat�rios");
	for(indice=0;indice < TAM;indice++){
		scanf("%d \n", &numeros[indice]);
	}//fim for
	
	printf("Ordem atual dos numeros em cada indide do array: \n");
	
	for (indice = 0; indice <TAM; indice++)
		printf("%4d", numeros[indice]);
	
	//Algoritimo de ordena��o Bubblesort
	troca = 1; //inicializa flag como verdadeiro
  	while (troca) { //loop enquanto houve troca
    troca = 0; 
	for (contador =1; contador < TAM; contador++){
		for(indice=0;indice < TAM-1; indice++){
			if(numeros[indice]> numeros[indice+1]){
				auxiliar = numeros[indice];
				numeros[indice] = numeros[indice+1];
				numeros[indice+1 ]=auxiliar;
				troca = 1; //sinaliza que houve troca
				  // imprime as trocas
      printf("\nTrocando %d com %d\n", numeros[indice], numeros[indice+1]);
			}
		}
	}//fim for
	printf("\n Elementos em ordem crescente:\n");
	
	for (indice= 0; indice < TAM; indice++){
		printf("%4d", numeros[indice]);
	}
	printf("\n");
	return 0;
	}//fim while
}

